import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'kanban';

  data = [
    {state: 'new', name: 'fewfwef'},
    {state: 'new', name: 'dfbkm'},
    {state: 'progress', name: 'wef'},
    {state: 'progress', name: 'elr;g'},
    {state: 'progress', name: 'eklbmrepomer'},
    {state: 'done', name: 'wefwef'},
  ]

  _new = this.data.filter(x => x.state === 'new');

  _progress = this.data.filter(x => x.state === 'progress');

  _done;
}

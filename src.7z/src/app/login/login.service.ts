import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class LoginService {

  constructor(private http: HttpClient) { }

  loginUser(login: string, password: string) {
    return this.http.get(`http://localhost:3001/api/login?l=${login}&p=${password}`);
  }

  
}

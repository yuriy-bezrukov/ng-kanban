export const environment = {
  production: true,
  hostName: 'site-api-my.com'
};
